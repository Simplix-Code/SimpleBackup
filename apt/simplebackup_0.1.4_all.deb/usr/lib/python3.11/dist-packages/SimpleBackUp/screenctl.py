import os
import time
import subprocess

SCREEN_NAME = "SimpleBackUp"

def start():
    res = subprocess.run(["screen", "-ls"], capture_output=True, text=True)
    if SCREEN_NAME.lower() in res.stdout.lower():
        print("[WARN] screen already started.")
        return
    os.system(f"screen -dmS {SCREEN_NAME} bash -c 'simplebackup run'")
    print("[OK] screen started.")

def stop():
    res = subprocess.run(["screen", "-ls"], capture_output=True, text=True)
    if SCREEN_NAME.lower() not in res.stdout.lower():
        print("[WARN] no screen found.")
        return
    os.system(f"screen -S {SCREEN_NAME} -X quit")
    print("[OK] delete screen.")

def restart():
    stop()
    time.sleep(1)
    start()
